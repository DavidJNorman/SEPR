<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="map-tiles-64" tilewidth="64" tileheight="64" tilecount="96" columns="16">
 <image source="tiles_sheet.png" width="1024" height="384"/>
</tileset>

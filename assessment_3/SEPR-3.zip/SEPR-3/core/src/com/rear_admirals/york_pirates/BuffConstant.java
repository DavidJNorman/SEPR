package com.rear_admirals.york_pirates;
/*[NEW ASSESSMENT 3] All this code was written within assessment 3 for a shop based purchasable buff system.

2 type of buff and corresponding constants are provided edit easily
*/
public class BuffConstant {
    public String ATTACK_BUFF_TAG = "attack";
    public int ATTACK_BUFF = 10;
    public int ATTACK_BUFF_PRICE = 10;
    public int ARRACK_BUFF_TURNS = 2;

    public String ACCURACY_BUFF_TAG = "accuracy";
    public int ACCURACY_BUFF = 3;
    public int ACCURACY_BUFF_PRICE = 20;
    public int ACCURACY_BUFF_TURN = 2;


}

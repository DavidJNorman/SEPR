package com.seaofgeese.game;


import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class BuildingTest{

    @Test
    public void testSetVanbrughBoss(){
        MainGame myMainGame = new MainGame();
        Building myBuilding = new Building(myMainGame, 4);
        myBuilding.setVanbrughBoss();

        assertEquals(myBuilding.getId(), 2, "Compare correct ID");
        assertEquals(Character.IDs.NEUTRAL, myBuilding.getIdType(), "Compare Correct EnemyType");
        assertEquals(60, myBuilding.getGold(),"Check gold reward is correct");
        assertEquals(3000, myBuilding.getPoints(), "Check point reward is correct");
        assertEquals(3, myBuilding.noOfCannons,"Check correct cannons");
        assertEquals(200, myBuilding.structureHealth,"Check correct Structure Health");
    }

    @Test
    public void testSetJamesBoss() {
        MainGame myMainGame = new MainGame();
        Building myBuilding = new Building(myMainGame, 4);
        myBuilding.setJamesBoss();

        assertEquals(myBuilding.getId(), 4, "Compare correct ID");
        assertEquals(Character.IDs.NEUTRAL, myBuilding.getIdType(), "Compare Correct EnemyType");
        assertEquals(90, myBuilding.getGold(),"Check gold reward is correct");
        assertEquals(1700, myBuilding.getPoints(), "Check point reward is correct");
        assertEquals(4, myBuilding.noOfCannons,"Check correct cannons");
        assertEquals(250, myBuilding.structureHealth,"Check correct Structure Health");
    }

    @Test
    public void testSetHalifaxBoss() {
        MainGame myMainGame = new MainGame();
        Building myBuilding = new Building(myMainGame, 4);
        myBuilding.setHalifaxBoss();

        assertEquals(myBuilding.getId(), 6, "Compare correct ID");
        assertEquals(Character.IDs.NEUTRAL, myBuilding.getIdType(), "Compare Correct EnemyType");
        assertEquals(250, myBuilding.getGold(),"Check gold reward is correct");
        assertEquals(5000, myBuilding.getPoints(), "Check point reward is correct");
        assertEquals(5, myBuilding.noOfCannons,"Check correct cannons");
        assertEquals(350, myBuilding.structureHealth,"Check correct Structure Health");
    }

    @Test
    public void testSetPhysicsDepartment() {
        MainGame myMainGame = new MainGame();
        Building myBuilding = new Building(myMainGame, 4);
        myBuilding.setPhysicsDepartment();

        assertEquals(myBuilding.getId(), 9, "Compare correct ID");
        assertEquals(Character.IDs.ENEMY, myBuilding.getIdType(), "Compare Correct EnemyType");
        assertEquals(250, myBuilding.getGold(),"Check gold reward is correct");
        assertEquals(4000, myBuilding.getPoints(), "Check point reward is correct");
        assertEquals(4, myBuilding.noOfCannons,"Check correct cannons");
        assertEquals(300, myBuilding.structureHealth,"Check correct Structure Health");
    }

    @Test
    public void testSetBiologyDepartment() {
        MainGame myMainGame = new MainGame();
        Building myBuilding = new Building(myMainGame, 4);
        myBuilding.setBiologyDepartment();

        assertEquals(myBuilding.getId(), 10, "Compare correct ID");
        assertEquals(Character.IDs.ENEMY, myBuilding.getIdType(), "Compare Correct EnemyType");
        assertEquals(300, myBuilding.getGold(),"Check gold reward is correct");
        assertEquals(4500, myBuilding.getPoints(), "Check point reward is correct");
        assertEquals(4, myBuilding.noOfCannons,"Check correct cannons");
        assertEquals(350, myBuilding.structureHealth,"Check correct Structure Health");
    }
}

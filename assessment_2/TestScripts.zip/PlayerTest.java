package com.seaofgeese.game;


import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class PlayerTest {


    @Test
    void testUpdatePoints() {
        MainGame myMainGame = new MainGame();
        myMainGame.assignBasics();
        Player player = myMainGame.getPlayer();
        int pointsBefore = player.getPoints();
        player.UpdatePoints(100);
        int pointsAfter = player.getPoints();
        assertEquals(pointsBefore + 100, pointsAfter, "Check update points");
    }

    @Test
    void testUpdateGold() {
        MainGame myMainGame = new MainGame();
        myMainGame.assignBasics();
        Player player = myMainGame.getPlayer();
        int GoldBefore = player.getGold();
        player.UpdateGold(100);
        int GoldAfter = player.getGold();
        assertEquals(GoldBefore + 100, GoldAfter, "Check update points");
    }

}

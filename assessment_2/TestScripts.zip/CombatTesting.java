package com.seaofgeese.game;

import org.junit.Assert;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

//This is the file for testing the combat screen
//For this to work we need to unify code in MainGame and code in CombatTesting


public class CombatTesting{

    @Test
    public void testEnemyAttack(){      //SYSTEM TEST
        MainGame myMainGame = new MainGame();
        myMainGame.assignBasics();
        Ship enemyShip = myMainGame.getShip(0);
        CombatScreen myCombatScreen = new CombatScreen(myMainGame, enemyShip);

        int PlayerHealth = myMainGame.getPlayer().getStructureHealth();
        int enemyChoice = 0;
        myCombatScreen.e_attack();
        int NewPlayerHealth = myMainGame.getPlayer().getStructureHealth();
        assertEquals(PlayerHealth, NewPlayerHealth, "Compare health before and after");

        Building myBuilding = myMainGame.getBuilding(4);
        CombatScreen myNewCombatScreen = new CombatScreen(myMainGame, myBuilding);
        PlayerHealth = myMainGame.getPlayer().getStructureHealth();
        System.out.println(PlayerHealth);
        enemyChoice = 0;
        myNewCombatScreen.e_attack();
        NewPlayerHealth = myMainGame.getPlayer().getStructureHealth();
        System.out.println(NewPlayerHealth);
        assertEquals(PlayerHealth, NewPlayerHealth, "Compare health before and after");
    }

    @Test
    public void testPlayerAttack(){      //SYSTEM TEST
        MainGame myMainGame = new MainGame();
        myMainGame.assignBasics();
        System.out.println(myMainGame.getBuilding(4));
        Ship enemyShip = myMainGame.getShip(0);
        CombatScreen myCombatScreen = new CombatScreen(myMainGame, enemyShip);

        int EnemyHealth = enemyShip.getStructureHealth();
        System.out.println(EnemyHealth);
        myCombatScreen.p_attack();
        int NewEnemyHealth = enemyShip.getStructureHealth();
        System.out.println(EnemyHealth);
        assertNotEquals(EnemyHealth, NewEnemyHealth, "Compare health before and after");

        Building myBuilding = myMainGame.getBuilding(4);
        CombatScreen myNewCombatScreen = new CombatScreen(myMainGame, myBuilding);
        EnemyHealth = myBuilding.getStructureHealth();
        System.out.println(EnemyHealth);
        myNewCombatScreen.p_attack();
        NewEnemyHealth = myBuilding.getStructureHealth();
        System.out.println(NewEnemyHealth);
        assertNotEquals(EnemyHealth, NewEnemyHealth, "Compare health before and after");

    }

    @Test
    public void testCollegeCapture(){      //SYSTEM TEST
        MainGame myMainGame = new MainGame();
        myMainGame.assignBasics();
        Building myBuilding = myMainGame.getBuilding(0);
        myBuilding.structureHealth = 1;
        CombatScreen myCombatScreen = new CombatScreen(myMainGame, myBuilding);
        System.out.println(myBuilding.id);
        assertEquals(Character.IDs.NEUTRAL, myBuilding.id, "If ID is Friendly we know it's captured");
        myCombatScreen.p_attack();
        System.out.println(myBuilding.id);
        assertEquals(Character.IDs.FRIENDLY, myBuilding.id, "If ID is Friendly we know it's captured");


    }

    @Test
    public void testDepartmentHealthReset(){      //SYSTEM TEST
        MainGame myMainGame = new MainGame();
        myMainGame.assignBasics();
        Building myBuilding = myMainGame.getBuilding(4);
        CombatScreen myCombatScreen = new CombatScreen(myMainGame, myBuilding);
        myBuilding.structureHealth = 1;
        myCombatScreen.resetCollegeHealth();
        assertEquals(350, myBuilding.structureHealth, "Test reset");

    }
}

package com.seaofgeese.game;

public class Combat {




    //TODO decide if methods should be private

    private void loadCombat() {}

    private void updateTurn() {}

    private void attack(String weapon) {

    }
    private void spAttack(){

        }

    private void enemyAttack() {}

    //TODO private void minigame() ???
}
